export default function Brand(){return <a className="brand" href="/"><img src="/logo.jpg" width="40" height="40" alt="Логотип Рейс"/><span>рейс</span></a>}
