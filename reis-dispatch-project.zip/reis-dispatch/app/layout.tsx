import type { Metadata } from "next";
import "./globals.css";
import "./finance.css";

export const metadata: Metadata = {
  title: "Рейс — диспетчерская",
  description: "Рабочее пространство диспетчера: машины, водители, рейсы, клиенты, документы и финансы.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/logo.jpg",
    shortcut: "/logo.jpg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
