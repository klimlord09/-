import AuthForm from '@/components/reis/auth-form';export default function Register(){return <AuthForm register/>}
