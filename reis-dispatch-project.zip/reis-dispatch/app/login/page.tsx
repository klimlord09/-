import AuthForm from '@/components/reis/auth-form';export default function Login(){return <AuthForm/>}
