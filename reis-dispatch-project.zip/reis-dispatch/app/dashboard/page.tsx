import {redirect} from 'next/navigation';import {currentUser} from '@/lib/auth';import Dashboard from '@/components/reis/dashboard';
export default async function Page(){const user=await currentUser();if(!user)redirect('/login');return <Dashboard user={user}/>}
