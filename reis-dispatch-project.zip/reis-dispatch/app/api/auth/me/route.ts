import {requireUser} from '@/lib/auth';import {failure} from '@/lib/server';
export async function GET(){try{return Response.json({user:await requireUser()},{headers:{'Cache-Control':'no-store'}})}catch(e){return failure(e)}}
