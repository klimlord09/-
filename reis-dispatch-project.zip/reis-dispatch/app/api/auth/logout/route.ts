import {endSession} from '@/lib/auth';import {failure,sameOrigin} from '@/lib/server';
export async function POST(req:Request){try{sameOrigin(req);return Response.json({ok:true},{headers:{'Set-Cookie':await endSession(req),'Cache-Control':'no-store'}})}catch(e){return failure(e)}}
