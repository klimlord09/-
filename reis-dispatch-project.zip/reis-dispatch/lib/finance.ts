export type TripFinance = { distance:number; consumption:number; fuelPrice:number; driverPay:number; tolls:number; other:number; commissionPercent:number; paid:number };
export const emptyFinance:TripFinance={distance:0,consumption:0,fuelPrice:0,driverPay:0,tolls:0,other:0,commissionPercent:0,paid:0};
const round=(n:number)=>Math.round((n+Number.EPSILON)*100)/100;
export function calculateFinance(rate:number,f:TripFinance){
 const fuel=round(f.distance*f.consumption/100*f.fuelPrice);
 const commission=round(rate*f.commissionPercent/100);
 const costs=round(fuel+commission+f.driverPay+f.tolls+f.other);
 const profit=round(rate-costs);
 return {fuel,commission,costs,profit,margin:rate>0?round(profit/rate*100):null,perKm:f.distance>0?round(profit/f.distance):null,due:round(Math.max(0,rate-f.paid)),overpaid:round(Math.max(0,f.paid-rate))};
}
export function validateFinance(f:TripFinance){
 if(!f||typeof f!=='object'||Array.isArray(f))throw Error('Проверьте финансовые данные');
 for(const key of Object.keys(emptyFinance) as (keyof TripFinance)[]){const value=f[key];if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>1000000000)throw Error('Расходы и оплата должны быть неотрицательными числами');}
 if(f.commissionPercent>100)throw Error('Комиссия не может превышать 100%');
 if(f.distance>1000000||f.consumption>1000||f.fuelPrice>100000)throw Error('Проверьте расстояние и расход топлива');
}
