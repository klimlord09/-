import {scryptSync,randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {headers} from 'next/headers';
import {db,HttpError} from './server';
const cookieName='reis_session';
export const digest=(v:string)=>createHash('sha256').update(v).digest('hex');
export function hashPassword(password:string,salt=randomBytes(16).toString('hex')){return salt+':'+scryptSync(password,salt,64,{N:32768,r:8,p:3,maxmem:48*1024*1024}).toString('hex')}
export function verifyPassword(password:string,stored:string){const salt=stored.split(':')[0];const candidate=hashPassword(password,salt);return candidate.length===stored.length&&timingSafeEqual(Buffer.from(candidate),Buffer.from(stored))}
export type User={id:string;email:string;name:string};
export async function currentUser(){const h=await headers();const raw=h.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith(cookieName+'='))?.slice(cookieName.length+1);if(!raw||!/^[a-f0-9]{64}$/.test(raw))return null;return db().prepare('SELECT a.id,a.email,a.name FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token=? AND s.expires>?').bind(digest(raw),Date.now()).first<User>()}
export async function requireUser(){const user=await currentUser();if(!user)throw new HttpError(401,'Войдите в аккаунт');return user}
export async function sessionCookie(userId:string,req:Request){const raw=randomBytes(32).toString('hex');await db().prepare('INSERT INTO sessions(token,account_id,expires) VALUES(?,?,?)').bind(digest(raw),userId,Date.now()+7*86400000).run();return cookieName+'='+raw+'; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800'+(new URL(req.url).protocol==='https:'?'; Secure':'')}
export async function endSession(req:Request){const raw=req.headers.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith(cookieName+'='))?.slice(cookieName.length+1);if(raw)await db().prepare('DELETE FROM sessions WHERE token=?').bind(digest(raw)).run();return cookieName+'=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0'+(new URL(req.url).protocol==='https:'?'; Secure':'')}
export async function throttle(key:string,limit:number,windowMs:number){const now=Date.now();const row=await db().prepare('INSERT INTO auth_attempts(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<? THEN 1 ELSE count+1 END,expires=CASE WHEN expires<? THEN excluded.expires ELSE expires END RETURNING count').bind(digest(key),now+windowMs,now,now).first<{count:number}>();if(!row||row.count>limit)throw new HttpError(429,'Слишком много попыток. Попробуйте позже.');}
